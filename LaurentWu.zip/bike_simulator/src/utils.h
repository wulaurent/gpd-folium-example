#ifndef UTILS_H
#define UTILS_H

#include <GLFW/glfw3.h>
#include <fstream>
#include <string>
#include <iostream>
#include <glm/glm.hpp>
#include <vector>

struct Vertex {
    glm::vec3 position;
    glm::vec3 normal;
    glm::vec2 texCoord;
};

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
std::string getDirectoryFromPath(const std::string& path);
std::string loadShaderSource(const std::string& filePath);
std::string getDirectoryFromPath(const std::string& path);

#endif // UTILS_H

#ifndef DAYNIGHTCYCLE_H
#define DAYNIGHTCYCLE_H

#include <glm/glm.hpp>

class DayNightCycle {
public:
    DayNightCycle(float fullCycleDuration);
    void update(float deltaTime);
    glm::vec3 getBackgroundColor() const;
    float getLightIntensity() const;

private:
    float cycleDuration;
    float time;
};

#endif // DAYNIGHTCYCLE_H

#include "shader.h"
#include <fstream>
#include <sstream>

// compile le shader à partir d'un vertex et fragment shader
Shader::Shader(const char* vertexPath, const char* fragmentPath) {
    std::string vertexCode = loadShaderSource(vertexPath);
    std::string fragmentCode = loadShaderSource(fragmentPath);

    if (vertexCode.empty() || fragmentCode.empty()) {
        std::cerr << "erreur : Impossible de charger les shaders depuis " << vertexPath << " ou " << fragmentPath << std::endl;
        ID = 0;
        return;
    }

    GLuint vertexShader = compileShader(vertexCode.c_str(), GL_VERTEX_SHADER);
    GLuint fragmentShader = compileShader(fragmentCode.c_str(), GL_FRAGMENT_SHADER);

    if (vertexShader == 0 || fragmentShader == 0) {
        ID = 0;
        return;
    }

    // link le programme shader
    ID = glCreateProgram();
    glAttachShader(ID, vertexShader);
    glAttachShader(ID, fragmentShader);
    glLinkProgram(ID);

    int success;
    char infoLog[512];
    glGetProgramiv(ID, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(ID, 512, nullptr, infoLog);
        std::cerr << "erreur de linkage du programme de shaders : " << infoLog << std::endl;
        ID = 0;
    }

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
}

// bind le shader
void Shader::bind() const {
    glUseProgram(ID);
}

// valeur matricielle pour un uniform
void Shader::setUniform(const std::string& name, const glm::mat4& value) const {
    glUniformMatrix4fv(glGetUniformLocation(ID, name.c_str()), 1, GL_FALSE, glm::value_ptr(value));
}

// int value pour un uniform
void Shader::setUniform(const std::string& name, int value) const {
    glUniform1i(glGetUniformLocation(ID, name.c_str()), value);
}

// float value pour un uniform
void Shader::setUniform(const std::string& name, float value) const {
    glUniform1f(glGetUniformLocation(ID, name.c_str()), value);
}

// vecteur 3d pour un uniform
void Shader::setUniform(const std::string &name, const glm::vec3 &value) const {
    glUniform3fv(glGetUniformLocation(ID, name.c_str()), 1, glm::value_ptr(value));
}

// unbind
Shader::~Shader() {
    glDeleteProgram(ID);
}

// charge le shader à partir d'un fichier
std::string Shader::loadShaderSource(const char* filePath) const {
    std::ifstream file;
    std::stringstream buffer;

    file.open(filePath);
    if (!file.is_open()) {
        std::cerr << "erreur : Impossible d'ouvrir le fichier " << filePath << std::endl;
        return "";
    }

    buffer << file.rdbuf();
    file.close();

    return buffer.str();
}

// compile le shader
GLuint Shader::compileShader(const char* source, GLenum type) const {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);

    int success;
    char infoLog[512];
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shader, 512, nullptr, infoLog);
        std::cerr << "erreur de compilation du shader ("
                  << ((type == GL_VERTEX_SHADER) ? "Vertex" : "Fragment")
                  << "): " << infoLog << std::endl;
        glDeleteShader(shader);
        return 0;
    }

    return shader;
}

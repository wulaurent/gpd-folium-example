#pragma once

#include <vector>
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <tiny_obj_loader.h>
#include "stb_image.h"
#include "shader.h"
#include "utils.h"

class Bike {
public:
    Bike(const char* objPath, const char* mtlPath, float speed);
    ~Bike();
    void update(float deltaTime, const std::vector<glm::vec3>& path);
    void render(Shader& shader, const glm::mat4& view, const glm::mat4& projection);
    glm::vec3 getPosition() const;
    glm::mat4 getModelMatrix() const;
    glm::vec3 getDirection() const;

private:
    float bikePosition;
    float bikeSpeed;
    glm::vec3 bikePos;
    glm::mat4 bikeModel;
    GLuint VAO, VBO, bikeTexture;
    std::vector<Vertex> vertices;
    glm::vec3 bikeDirection;

    void loadModel(const char* objPath, const char* mtlPath);
    glm::vec3 getBikePosition(float t, const std::vector<glm::vec3>& path);
    GLuint loadTexture(const char* path);
};

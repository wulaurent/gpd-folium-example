#include "camera.h"

Camera::Camera(glm::vec3 position, glm::vec3 up, float yaw, float pitch, float speed, float sensitivity)
    : position(position), worldUp(up), yaw(yaw), pitch(pitch), speed(speed), sensitivity(sensitivity),
      firstMouse(true), lastX(0.0f), lastY(0.0f) {
    updateCameraVectors();
}

// calcul la matrice de vue de conversion des coordonnées monde vers caméra
glm::mat4 Camera::getViewMatrix() const {
    return glm::lookAt(position, position + front, up);
}

// return la position de la caméra
glm::vec3 Camera::getPosition() const {
    return position;
}

// met à jour la nouvelle position
void Camera::setPosition(const glm::vec3& newPosition) {
    position = newPosition;
}

// orientation de la caméra
void Camera::lookAt(const glm::vec3& target) {
    front = glm::normalize(target - position);
    right = glm::normalize(glm::cross(front, worldUp));
    up = glm::normalize(glm::cross(right, front));
}

// binding des touches claviers pour la caméra
void Camera::processKeyboardInput(GLFWwindow* window, float deltaTime) {
    float velocity = speed * deltaTime;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        position += front * velocity;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        position -= front * velocity;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        position -= right * velocity;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        position += right * velocity;
}

// modification de l'angle de rotation à la souris
void Camera::processMouseMovement(float xoffset, float yoffset) {
    if (firstMouse) {
        firstMouse = false;
        return;
    }

    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    // blocage de cadran
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    updateCameraVectors();
}

// reset la position lors de la première instance
void Camera::resetMousePosition(float xpos, float ypos) {
    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    processMouseMovement(xoffset, yoffset);
}

// recalcul des vecteurs directionnels de la caméra
void Camera::updateCameraVectors() {
    glm::vec3 newFront;
    newFront.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    newFront.y = sin(glm::radians(pitch));
    newFront.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    front = glm::normalize(newFront);

    right = glm::normalize(glm::cross(front, worldUp));
    up = glm::normalize(glm::cross(right, front));
}

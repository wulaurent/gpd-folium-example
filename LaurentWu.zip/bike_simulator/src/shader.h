#ifndef SHADER_H
#define SHADER_H

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <string>
#include <iostream>

class Shader {
public:
    GLuint ID;
    Shader(const char* vertexPath, const char* fragmentPath);
    Shader(GLuint existingProgramID);
    void bind() const;
    void setUniform(const std::string& name, const glm::mat4& value) const; // uniform mat4
    void setUniform(const std::string& name, int value) const; // uniform int
    void setUniform(const std::string& name, float value) const; // uniform float
    void setUniform(const std::string &name, const glm::vec3 &value) const;
    ~Shader();

private:
    std::string loadShaderSource(const char* filePath) const;
    GLuint compileShader(const char* source, GLenum type) const;
};

#endif // SHADER_H

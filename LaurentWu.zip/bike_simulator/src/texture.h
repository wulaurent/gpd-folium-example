#ifndef TEXTURE_H
#define TEXTURE_H

#include <GL/glew.h>
#include <string>
#include <unordered_map>

class Texture {
public:
    static Texture& getInstance();
    GLuint loadTexture(const std::string& path);
    void Unbind();
    Texture(const Texture&) = delete;
    Texture& operator=(const Texture&) = delete;

private:
    Texture();
    ~Texture();
    std::unordered_map<std::string, GLuint> texturesCache;
};

#endif // TEXTURE_H

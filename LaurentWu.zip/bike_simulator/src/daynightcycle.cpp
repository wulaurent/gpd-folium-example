#include "daynightcycle.h"
#include <glm/glm.hpp>
#include <glm/gtx/compatibility.hpp>

DayNightCycle::DayNightCycle(float fullCycleDuration)
    : cycleDuration(fullCycleDuration), time(0.0f) {}

// met à jour le cycle jour/nuit en fonction du temps
void DayNightCycle::update(float deltaTime) {
    time += deltaTime;
    if (time > cycleDuration) {
        time -= cycleDuration;
    }
}

// retourne la couleur du fond en fonction du cycle
glm::vec3 DayNightCycle::getBackgroundColor() const {
    float phase = time / cycleDuration;

    // division jour / nuit
    if (phase < 0.5f) {
        return glm::mix(glm::vec3(0.5f, 0.7f, 1.0f), glm::vec3(0.1f, 0.1f, 0.2f), phase * 2.0f);
    } else {
        return glm::mix(glm::vec3(0.1f, 0.1f, 0.2f), glm::vec3(0.5f, 0.7f, 1.0f), (phase - 0.5f) * 2.0f);
    }
}

// retourne l'intensité lumineuse en fonction du cycle
float DayNightCycle::getLightIntensity() const {
    float phase = time / cycleDuration;

    if (phase < 0.5f) {
        return glm::mix(1.0f, 0.2f, phase * 2.0f);
    } else {
        return glm::mix(0.2f, 1.0f, (phase - 0.5f) * 2.0f);
    }
}

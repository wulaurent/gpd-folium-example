#ifndef ROAD_H
#define ROAD_H

#include <vector>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include "utils.h"

class Road {
public:
    Road(float radius, float width, float height, const std::string& texturePath);
    ~Road();
    void render(const glm::mat4& view, const glm::mat4& projection, GLuint shaderProgram);
    const std::vector<glm::vec3>& getCenterPath() const;

private:
    void createRoad();
    GLuint createAndLoadTexture(const std::string& path);
    std::vector<Vertex> vertices;
    std::vector<glm::vec3> centerPath;
    GLuint VAO, VBO, textureID;
    float radius, width, height;
    std::string texturePath;
};

#endif // ROAD_H

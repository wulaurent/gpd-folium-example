#include "bike.h"
#include <iostream>
#include <stdexcept>
#include "texture.h"

Bike::Bike(const char* objPath, const char* mtlPath, float speed)
    : bikePosition(0.0f), bikeSpeed(speed), VAO(0), VBO(0), bikeTexture(0) {
    loadModel(objPath, mtlPath);
}

Bike::~Bike() {
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    if (bikeTexture != 0) {
        glDeleteTextures(1, &bikeTexture);
    }
}

// return la position actuelle du vélo
glm::vec3 Bike::getPosition() const {
    return bikePos;
}

// return la matrice de transformation qui place et oriente le vélo
glm::mat4 Bike::getModelMatrix() const {
    return bikeModel;
}

// return la direction actuelle du vélo
glm::vec3 Bike::getDirection() const {
    return bikeDirection;
}

// met à jour la matrice, la position et la direction en fonction du temps
void Bike::update(float deltaTime, const std::vector<glm::vec3>& path) {
    bikePosition += bikeSpeed * deltaTime;
    if (bikePosition > 1.0f) {
        bikePosition -= 1.0f;
    }

    bikePos = getBikePosition(bikePosition, path);
    glm::vec3 nextPos = getBikePosition(bikePosition + 0.001f, path);

    bikeDirection = glm::normalize(nextPos - bikePos);

    static float previousAngle = 0.0f;
    float angle = atan2(-bikeDirection.x, -bikeDirection.z);

    if (angle - previousAngle > glm::radians(180.0f)) {
        angle -= glm::radians(360.0f);
    } else if (previousAngle - angle > glm::radians(180.0f)) {
        angle += glm::radians(360.0f);
    }
    previousAngle = angle;

    // oriente le vélo de la bonne manière
    bikeModel = glm::mat4(1.0f);
    bikeModel = glm::translate(bikeModel, bikePos);
    bikeModel = glm::rotate(bikeModel, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    bikeModel = glm::rotate(bikeModel, angle, glm::vec3(0.0f, 0.0f, 1.0f));
    bikeModel = glm::scale(bikeModel, glm::vec3(0.02f));
}

// render le vélo à partir du shader et du view/projection de la caméra
void Bike::render(Shader& shader, const glm::mat4& view, const glm::mat4& projection) {
    shader.bind();

    shader.setUniform("model", bikeModel);
    shader.setUniform("view", view);
    shader.setUniform("projection", projection);
    shader.setUniform("useTexture", bikeTexture != 0);

    // applique la texture du vélo
    if (bikeTexture != 0) {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, bikeTexture);
        shader.setUniform("bikeTexture", 0);
    }

    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, vertices.size());
    glBindVertexArray(0);
}

// modélise le vélo et sa texture à partir d'un .obj et d'un mtl
void Bike::loadModel(const char* objPath, const char* mtlPath) {
    tinyobj::attrib_t attrib;
    std::vector<tinyobj::shape_t> shapes;
    std::vector<tinyobj::material_t> materials;
    std::string warnings, errors;

    std::string mtlDir = getDirectoryFromPath(mtlPath);
    bool success = tinyobj::LoadObj(&attrib, &shapes, &materials, &warnings, &errors, objPath, mtlDir.c_str());
    if (!success) {
        throw std::runtime_error("erreur lors du chargement du modèle OBJ : " + errors);
    }

    for (size_t i = 0; i < shapes.size(); i++) {
        const auto& mesh = shapes[i].mesh;
        for (size_t j = 0; j < mesh.indices.size(); j++) {
            const tinyobj::index_t& idx = mesh.indices[j];
            Vertex vertex;

            vertex.position = {
                attrib.vertices[3 * idx.vertex_index + 0],
                attrib.vertices[3 * idx.vertex_index + 1],
                attrib.vertices[3 * idx.vertex_index + 2]
            };

            vertex.normal = {
                attrib.normals[3 * idx.normal_index + 0],
                attrib.normals[3 * idx.normal_index + 1],
                attrib.normals[3 * idx.normal_index + 2]
            };

            vertex.texCoord = {
                attrib.texcoords[2 * idx.texcoord_index + 0],
                attrib.texcoords[2 * idx.texcoord_index + 1]
            };

            vertices.push_back(vertex);
        }
    }

    // load la texture à partir du mtl
    for (const auto& material : materials) {
            if (!material.diffuse_texname.empty()) {
                std::string texturePath = mtlDir + material.diffuse_texname;
                bikeTexture = Texture::getInstance().loadTexture(texturePath);
                break;
            }
        }

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * vertices.size(), vertices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, texCoord));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

// calcul la position interpolée en fonction de t
glm::vec3 Bike::getBikePosition(float t, const std::vector<glm::vec3>& path) {
    int numSegments = path.size() - 1;
    int segment = static_cast<int>(t * numSegments);
    float localT = (t * numSegments) - segment;

    glm::vec3 start = path[segment];
    glm::vec3 end = path[(segment + 1) % path.size()];

    // formule interpolation linéaire de lerp
    return (1 - localT) * start + localT * end;
}

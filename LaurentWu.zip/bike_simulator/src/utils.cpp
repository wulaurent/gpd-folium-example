#include "utils.h"

// gestion du redimensionnement de la fenetre
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// charge en string le contenu d'un shader
std::string loadShaderSource(const std::string& filePath) {
    std::ifstream shaderFile(filePath);
    if (!shaderFile.is_open()) {
        std::cerr << "erreur : Impossible d'ouvrir le fichier shader " << filePath << std::endl;
        return "";
    }
    return std::string((std::istreambuf_iterator<char>(shaderFile)),
                        std::istreambuf_iterator<char>());
}

// return le chemin du dossier à partir d'un fichier
std::string getDirectoryFromPath(const std::string& path) {
    size_t pos = path.find_last_of("/\\");
    if (pos != std::string::npos) {
        return path.substr(0, pos + 1);
    }
    return "";
}


#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "tiny_obj_loader.h"
#include <vector>
#include <fstream>
#include "stb_image.h"
#include <string>

#include "platform.h"
#include "camera.h"
#include "shader.h"
#include "road.h"
#include "bike.h"
#include "texture.h"
#include "daynightcycle.h"
#include "utils.h"

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"

const float CAMERASPEED = 9.0f;
const float SENSITIVITYCAMERA = 0.1f;
const float BIKESPEED = 0.15f;
const float CYCLETIME = 30.0f;

const std::string VERTEX_SHADER_PATH = std::string(PROJECT_ROOT) + "assets/shaders/VertexShader.Vertexshader";
const std::string PLATFORM_FRAGMENT_SHADER_PATH = std::string(PROJECT_ROOT) + "assets/shaders/PlatformFragmentShader.fragmentshader";
const std::string BIKE_FRAGMENT_SHADER_PATH = std::string(PROJECT_ROOT) + "assets/shaders/BikeFragmentShader.fragmentshader";

const std::string PLATFORM_TEXTURE = std::string(PROJECT_ROOT) + "assets/textures/grass.jpeg";
const std::string ROAD_TEXTURE = std::string(PROJECT_ROOT) + "assets/textures/road.png";

const std::string BIKE_OBJ = std::string(PROJECT_ROOT) + "assets/obj/bike.obj";
const std::string BIKE_MTL = std::string(PROJECT_ROOT) + "assets/obj/bike.mtl";

// indique si l'interface utilisateur est active
bool uiActive = false;

int main() {

    float lightIntensity;
    double savedMouseX = 0.0, savedMouseY = 0.0;
    bool lightModifiedByUser = false;
    bool followBike = false;

    // Initialisation GLFW
    if (!glfwInit()) return -1;

    GLFWwindow* window = glfwCreateWindow(1200, 1000, "OpenGL_API", nullptr, nullptr);
    if (!window) {
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    if (glewInit() != GLEW_OK) return -1;

    glClearColor(0.5f, 0.7f, 1.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    // instanciation de la caméra au centre de ma plateforme
    Camera camera(
        glm::vec3(0.0f, 8.0f, 30.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        -90.0f,
        0.0f,
        CAMERASPEED,
        SENSITIVITYCAMERA
    );

    glfwSetCursorPosCallback(window, [](GLFWwindow* window, double xpos, double ypos) {
        if (!uiActive) {
            Camera* localCamera = reinterpret_cast<Camera*>(glfwGetWindowUserPointer(window));
            if (localCamera) {
                localCamera->resetMousePosition(xpos, ypos);
            }
        }
    });
    glfwSetWindowUserPointer(window, &camera);

    // compile les shader
    Shader platformShader(VERTEX_SHADER_PATH.c_str(), PLATFORM_FRAGMENT_SHADER_PATH.c_str());
    Shader bikeShader(VERTEX_SHADER_PATH.c_str(), BIKE_FRAGMENT_SHADER_PATH.c_str());

    if (platformShader.ID == 0 || bikeShader.ID == 0) {
        std::cerr << "erreur : Impossible de créer les shaders." << std::endl;
        return -1;
    }

    // instanciation de mes objets scène
    Platform platform(10.0f, PLATFORM_TEXTURE.c_str());
    Road road(7.0f, 1.0f, 0.01f, ROAD_TEXTURE.c_str());
    DayNightCycle dayNightCycle(CYCLETIME);
    Bike bike(BIKE_OBJ.c_str(), BIKE_MTL.c_str(), BIKESPEED);

    std::vector<glm::vec3> roadCenterPath;
    roadCenterPath = road.getCenterPath();
    glm::vec3 lightColor(1.0f, 0.8f, 0.6f);

    // instanciation de ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");

    while (!glfwWindowShouldClose(window)) {
        float currentFrame = glfwGetTime();
        static float lastFrame = 0.0f;
        float deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        glfwPollEvents();

        static bool ctrlEPressed = false;
        bool isCtrlEPressed = (glfwGetKey(window, GLFW_KEY_LEFT_CONTROL) == GLFW_PRESS && glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS);

        // gestion du mode insertion par clavier
        if (isCtrlEPressed) {
            if (!ctrlEPressed) {
                uiActive = !uiActive;

                if (uiActive) {
                    glfwGetCursorPos(window, &savedMouseX, &savedMouseY);
                    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
                } else {
                    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
                    glfwSetCursorPos(window, savedMouseX, savedMouseY);
                }
            }
            ctrlEPressed = true;
        } else {
            ctrlEPressed = false;
        }

        // désactive la caméra lors du mode insertion
        if (!uiActive && !followBike) {
            camera.processKeyboardInput(window, deltaTime);
        }

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // panneau interactif des widgets
        if (uiActive) {
            ImGui::SetNextWindowSize(ImVec2(510.0f, 0.0f));
            ImGui::Begin("Contrôle de la lumière et de la vue");

            if (ImGui::SliderFloat("Intensité de la lumière ", &lightIntensity, 0.0f, 2.0f)) {
                lightModifiedByUser = true;
            }
            if (ImGui::ColorEdit3("Couleur de la lumière", glm::value_ptr(lightColor))) {
                lightModifiedByUser = true;
            }
            ImGui::Spacing();

            if (ImGui::Button("Réinitialiser la lumière")) {
                lightModifiedByUser = false;
            }

            ImGui::SameLine();
            if (ImGui::Button(followBike ? "Arrêter de suivre le vélo" : "Suivre le vélo")) {
                followBike = !followBike;
            }

            ImGui::End();
        }

        // mise à jour de la lumière et du cycle jour/nuit
        if (!uiActive && !lightModifiedByUser) {
            dayNightCycle.update(deltaTime);

            lightIntensity = glm::mix(2.0f, 0.5f, dayNightCycle.getLightIntensity());
            lightColor = glm::mix(glm::vec3(1.0f, 1.0f, 0.8f), glm::vec3(0.8f, 0.8f, 1.0f), dayNightCycle.getLightIntensity());
        }

        bike.update(deltaTime, roadCenterPath);

        // position de la caméra première personne
        if (followBike) {
            glm::vec3 bikePosition = bike.getPosition();
            glm::vec3 bikeDirection = bike.getDirection();

            glm::vec3 cameraOffset = glm::vec3(0.0f, 5.0f, -4.0f);
            glm::vec3 cameraPosition = bikePosition + bikeDirection * cameraOffset.z + glm::vec3(0.0f, cameraOffset.y, 0.0f);

            camera.setPosition(cameraPosition);

            camera.lookAt(bikePosition + bikeDirection * 15.0f);
        }

        // calcul la position de la lumière
        glm::vec3 bikePosition = bike.getPosition();
        glm::vec3 bikeDirection = bike.getDirection();
        glm::vec3 lightOffset = bikeDirection * 4.0f;
        glm::vec3 lightPosition = bikePosition + lightOffset + glm::vec3(0.0f, 4.0f, 0.0f);

        // changement de couleur en fonction du cycle jour/nuit
        glm::vec3 backgroundColor = dayNightCycle.getBackgroundColor();
        glClearColor(backgroundColor.r, backgroundColor.g, backgroundColor.b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // transmission de la couleur aux objets en fonction du cycle
        platformShader.bind();
        platformShader.setUniform("lightPos", lightPosition);
        platformShader.setUniform("lightColor", lightColor);
        platformShader.setUniform("lightIntensity", lightIntensity);
        platformShader.setUniform("timeOfDay", dayNightCycle.getLightIntensity());

        // calcul matrice vue/projection
        glm::mat4 view = camera.getViewMatrix();
        glm::mat4 projection = glm::perspective(glm::radians(45.0f), 1200.0f / 1000.0f, 0.1f, 100.0f);

        // affichage de la plateforme
        glm::mat4 platformModel = glm::mat4(1.0f);
        platformShader.setUniform("model", platformModel);
        platformShader.setUniform("view", view);
        platformShader.setUniform("projection", projection);

        // affichage du vélo
        platform.render(platformShader.ID, platformModel, view, projection);
        bike.render(bikeShader, view, projection);

        // affichage de la route
        platformShader.bind();
        platformShader.setUniform("model", glm::mat4(1.0f));
        platformShader.setUniform("view", view);
        platformShader.setUniform("projection", projection);
        road.render(view, projection, platformShader.ID);

        // affichage de l'interface imgui
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // libère les ressources
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    Texture::getInstance().Unbind();
    glfwTerminate();
    return 0;
}

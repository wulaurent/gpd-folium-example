#include "road.h"
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include "stb_image.h"
#include "texture.h"

Road::Road(float radius, float width, float height, const std::string& texturePath)
    : radius(radius), width(width), height(height), texturePath(texturePath), VAO(0), VBO(0), textureID(0) {
    createRoad();
    textureID = createAndLoadTexture(texturePath);
}

Road::~Road() {
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteTextures(1, &textureID);
}

// créer une route circulaire segmentée à partir de sommets et d'indices
void Road::createRoad() {
    const int segments = 200;
    glm::vec3 center(0.0f, height, 0.0f);

    for (int i = 0; i < segments; ++i) {
        float t = static_cast<float>(i) / segments;
        float angle = t * glm::two_pi<float>();
        float nextAngle = (t + 1.0f / segments) * glm::two_pi<float>();

        glm::vec3 outer1(center.x + radius * cos(angle), height, center.z + radius * sin(angle));
        glm::vec3 inner1(center.x + (radius - width) * cos(angle), height, center.z + (radius - width) * sin(angle));
        glm::vec3 outer2(center.x + radius * cos(nextAngle), height, center.z + radius * sin(nextAngle));
        glm::vec3 inner2(center.x + (radius - width) * cos(nextAngle), height, center.z + (radius - width) * sin(nextAngle));

        glm::vec3 centerPos = (outer1 + inner1) / 2.0f;
        centerPath.push_back(centerPos);

        vertices.push_back({ outer1, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 0.0f) });
        vertices.push_back({ inner1, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 0.0f) });
        vertices.push_back({ outer2, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 1.0f) });

        vertices.push_back({ outer2, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 1.0f) });
        vertices.push_back({ inner1, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 0.0f) });
        vertices.push_back({ inner2, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 1.0f) });
    }

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), vertices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, texCoord));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

// charge la texture de ma route
GLuint Road::createAndLoadTexture(const std::string& path) {
    return Texture::getInstance().loadTexture(path);
}

// rendu de la route à partir du shader et de la matrice de transformation
void Road::render(const glm::mat4& view, const glm::mat4& projection, GLuint shaderProgram) {
    glUseProgram(shaderProgram);

    glm::mat4 model = glm::mat4(1.0f);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, &model[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, &view[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, &projection[0][0]);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);

    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, vertices.size());
    glBindVertexArray(0);
}

// return le centre de la route
const std::vector<glm::vec3>& Road::getCenterPath() const {
    return centerPath;
}

#ifndef PLATFORM_H
#define PLATFORM_H

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <vector>
#include "stb_image.h"
#include "utils.h"

class Platform {
public:
    Platform(float size, const char* texturePath);
    ~Platform();
    void render(GLuint shaderProgram, const glm::mat4& model, const glm::mat4& view, const glm::mat4& projection);
    static GLuint loadTexture(const char* path);

private:
    GLuint VAO, VBO, EBO;
    GLuint textureID;
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;
    void setupPlatform();
};


#endif // PLATFORM_H

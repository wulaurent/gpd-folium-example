# Circulation en vélo

## Introduction

Ce document détaille le projet **Circulation en vélo (sujet 2)** en C++ et OpenGL.  

---

## Structure du Projet

### Organisation des Dossiers
- **`src/`** : Contient les fichiers source `.cpp` et `.h`
- **`lib/`** : Contient les fichiers source des bibliothèques utilisées
- **`assets/`** : Contient les assets (obj, textures, shaders)
- **`docs/`** : Contient cette documentation readme

---

## Fonctionnalités

- **Fonctionnalité 1** : Création d'un objet vélo
- **Fonctionnalité 2** : Création d'une plateforme
- **Fonctionnalité 3** : Création de la trajectoire du vélo et de la route
- **Fonctionnalité 4** : Création de la lumière du vélo
- **Fonctionnalité 5** : Création du cycle jour/nuit
- **Fonctionnalité 6** : Création d'une interface pour changer l'intensité et la couleur de la lumière
- **Fonctionnalité 7** : Création d'une interface pour placer la caméra en mode première personne

**A noter** :
- La caméra se déplace à l'aide des touches **Z**, **Q**, **S** et **D**, la souris est utilisée pour la rotation.
- Le mode insertion s'active avec la combinaison de touches **Ctrl + E**.

---

## Installation et Compilation

### Prérequis
- Le compilateur C++ (GCC)
- L'outil de build `Make` et `CMake`
- Dépendances : GLEW et GLFW

### Étapes de Compilation
1. Installer les dépendances :
```bash
apt-get install libglm-dev libglew-dev libglfw3-dev libglu1-mesa-dev libgl-dev libxrandr-dev libxi-dev libxinerama-dev libx11-dev
```

2. Accéder au dossier :
```bash
unzip LaurentWu.zip
cd bike_simulator
```

3. Compiler le projet :
```bash
mkdir build
cd build
cmake ..
make
```

4. Exécuter le programme :
```bash
./bike_simulator
```
